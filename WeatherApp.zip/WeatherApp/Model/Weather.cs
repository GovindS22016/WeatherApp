﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherApp.Model
{
    class Weather
    {
        public string Temperature { get; set; }
        public string Precipitation { get; set; }
    }
}
