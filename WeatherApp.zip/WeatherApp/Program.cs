﻿using System;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using WeatherApp.Model;

namespace WeatherApp
{
    class Program
    {
        static DataTable weatherDT = new DataTable();
        /// <summary>
        /// Main method
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            try
            {
                string filepath = @"../../../Data/RduWeatherDataDump.csv";
                weatherDT = ConvertCSVtoDataTable(filepath);
                PredictWeather();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        /// <summary>
        /// Predicts weather based on the csv data
        /// </summary>
        /// <param name="dateTime"></param>
        /// <returns>json object containing weather data</returns>
        static string PredictWeather(DateTime? dateTime = null)
        {
            var date = dateTime ?? DateTime.Now;

            try
            {
                foreach (DataRow row in weatherDT.Rows)
                {
                    if (row["Month"].ToString() == date.ToString("MMMM") && row["Day of Month"].ToString() == date.Day.ToString())
                    {
                        double maxTemp, minTemp, avgTemp, precipitation;

                        double.TryParse(row["Normal Max Temp"].ToString(), out maxTemp);
                        double.TryParse(row["Normal MinTemp"].ToString(), out minTemp);
                        avgTemp = (maxTemp + minTemp) / 2;

                        double.TryParse(row["Normal Precipitation"].ToString(), out precipitation);

                        Weather weather = new Weather
                        {
                            Temperature = avgTemp.ToString(),
                            Precipitation = precipitation.ToString()
                        };

                        var weatherDataJson = Newtonsoft.Json.JsonConvert.SerializeObject(weather);
                        Console.WriteLine(weatherDataJson);

                        return weatherDataJson;
                    }
                    
                }
                return string.Empty;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return string.Empty;
            }            
        }

        /// <summary>
        /// Converts csv data into a data table 
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <returns>data table</returns>
        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            try
            {
                StreamReader sr = new StreamReader(strFilePath);
                string[] headers = sr.ReadLine().Split(',');
                DataTable dt = new DataTable();
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    string[] rows = Regex.Split(sr.ReadLine(), ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < headers.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }
                return dt;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }
    }
}
